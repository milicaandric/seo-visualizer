///////////////////////////////////////////////////////////////////////////////
//
// Title: SEO Visualizer
// Lecture: 002
// Author: Milica Andric
// Email: andric@wisc.edu
// Description: Program that implements and tests an abstract data structure.
//
///////////////////////////////////////////////////////////////////////////////
package application;

/**
 * This class will test DataStructureADT.
 */
@SuppressWarnings("rawtypes")
public class TestDS extends DataStructureADTTest {

  /**
   * Returns JUnit test results for the data structure class being tested.
   * 
   * @return test results for name of the data structure class being tested
   */
  @Override
  protected DataStructureADT createInstance() {
    return new DS();
  }
}
